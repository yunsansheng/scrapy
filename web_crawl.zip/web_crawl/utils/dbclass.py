# coding:utf-8

from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
import sqlite3
from sqlalchemy.sql import text
from collections import namedtuple
from sqlalchemy.pool import NullPool
import json
import psycopg2



class Dbclass():
    def __init__(self, env):
        self._env = env
        self.tunnel, self._db = self.initdb()

    def initdb(self):
        assert self._env in ('ali_rmt','local')

        if self._env == 'ali_rmt':
            engine = create_engine(
                'postgresql+psycopg2://postgres:ali_one_@#@139.224.113.70:5432/translate',poolclass=NullPool)
            Session = sessionmaker(bind=engine)
            session = Session()

            return None, session
        elif self._env == 'local':
            engine = create_engine(
                'postgresql+psycopg2://postgres:ali_one_@#@139.224.113.70:5432/test', poolclass=NullPool)
            Session = sessionmaker(bind=engine)
            session = Session()
            return None, session


    def db_insert(self, sql, data):
        try:
            # data是字典列表数组
            self._db.execute(text(sql), data)

        except Exception as e:
            self._db.rollback()
            print(e)
            raise Exception('db_insert FAILED')
        else:
            self._db.commit()

    def db_del(self, sql):
        try:
            self._db.execute(sql)
        except BaseException:
            raise Exception('db_del FAILED')
        else:
            self._db.commit()

    def db_query(self, sql):
        try:
            result = self._db.execute(sql).fetchall()
            return result
        except BaseException:
            raise Exception('db_query FAILED')

    def db_execute(self, sql, msg):

        try:
            result = self._db.execute(sql).rowcount
            print(msg, ':', result, 'row')
            self._db.commit()
            return result
        except BaseException:
            print(sql)
            print(BaseException)
            raise Exception('db_excute FAILED')
        # else:
        #     self._db.commit()

    def close(self):

        self._db.close()
        if self.tunnel is not None:
            self.tunnel.close()


if __name__ == '__main__':
    db = Dbclass('local')
    rs = db.db_query('select * from t_translate_title;')
    print(rs)
    # rs = db.db_execute("insert into t_translate_title(title,batch) values ('tis', '123');",'test')
    # print(db.db_query("select title from t_translate_title;"))
    #


