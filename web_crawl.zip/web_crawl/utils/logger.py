import logging
import platform

plt = platform.system()

if plt == 'Linux':
    LOG_LOCATION_FILE = '/var/log/mycrawl.log'
elif plt =='Darwin':
    LOG_LOCATION_FILE = '/Users/hwang2/documents/test/test.log'
else:
    LOG_LOCATION_FILE = '/'




logging.basicConfig(level = logging.INFO,
                    filename=LOG_LOCATION_FILE,
                    filemode='a',
                    format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)