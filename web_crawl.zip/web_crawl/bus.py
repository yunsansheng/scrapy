#coding:utf-8
import requests
from utils.wechat_msg import Wechat
'''
{"segmentID":"-33463817","companyType":"1","gprsId":"68"}   南方泉 - 火车站
{"segmentID":"33463817","companyType":"1","gprsId":"68"}  火车站- 南方泉
'''
from datetime import  datetime
from utils.dbclass import Dbclass
import time


wechat=Wechat()
db = Dbclass('ali_rmt')


def get_info_68(url,headers,seg_id,payload):
    time.sleep(3)
    r = requests.post(url=url,headers=headers,data=payload)
    print(r.text)
    return r.json()
    # try:
    #     rs = r.json()
    #     assert rs["status"] == True
    #     #route_name  =rs["detail"]["routeName"]
    #     bus_rs = []
    #     for item in rs["detail"]["zxStationRunDetailInfos"][:4]:
    #         if len(item["zxStationBusDetailInfos"])!=0:
    #             bus_rs.append(f'{item["stationName"]}\n{item["zxStationBusDetailInfos"][0]["arrivalTime"]}')
    #             #bus_rs.append((item["stationName"],item["zxStationBusDetailInfos"][0]["arrivalTime"]))
    #     print('bus_rs',bus_rs)
    #
    #     if len(bus_rs) !=0: #消息空忽略
    #         msg_str = "\n".join(bus_rs)
    #         print(msg_str)
    #         rs_api = db.db_query(f"select send_msg,flag from t_bus_info where segment_id = '{seg_id}' and bus_date = timestamp 'today' order by update_time desc limit 1;")
    #         print('rs_api',rs_api)
    #
    #         if len(rs_api)==0: # 数据库还没记录
    #             send_flag = True
    #         elif rs_api[0][1] == 1: # 注意优先级高 如果已经被取消那么flag都update成1。 否则默认是null.
    #             send_flag = False
    #         elif rs_api[0][0] == msg_str:# 数据库已有至少一条记录，但消息和上次一样
    #             send_flag = False
    #         else:
    #             send_flag = True
    #
    #         print('send_flag',send_flag)
    #
    #         if send_flag ==True:
    #             db.db_execute(
    #                 f"insert into t_bus_info (bus_date,segment_id,send_msg,update_time) values (timestamp 'today','{seg_id}','{msg_str}',now());",
    #                 'insert')
    #             #bus_rs.append(route_name)
    #             bus_rs.append('<a href="http://www.beyou.pub/api/bus_cancel/33463817">取消本次提醒</a>')
    #             wechat.senddata("68路下行:火车站->南方泉\n\n"+"\n\n".join(bus_rs), ['henry', 'wangchao'])
    #
    # except:
    #     wechat.senddata("获取信息失败，请联系管理员", ['henry', 'wangchao'])
    #


def bus_main_info_68():
    url = 'http://rtapi.wxbus.com.cn/m/zxXqLineStationInfo/findRunDetailByRouteId'
    headers = {
        "Host": "rtapi.wxbus.com.cn",
        "Accept-Language": "zh-Hans-CN;q=1, en-CN;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "platform": "ios",
        "baseVersion": "1.7.4",
        "Content-Length": "56",
        "User-Agent": "WXNewBus/1.7.4 (iPhone; iOS 11.0.3; Scale/3.00)",
        "Content-Type": "application/json",
        "rtSign": "d49fb64bdac69a4c20fd8499883ddc43"
    }
    seg_id = "33463817"
    payload = "{\"segmentID\":\"33463817\",\"companyType\":\"1\",\"gprsId\":\"68\"}"
    # rs = get_info_68(url,headers,seg_id,payload)

    try:
        rs_api = db.db_query(
            f"select send_msg,flag from t_bus_info where segment_id = '{seg_id}' and bus_date = timestamp 'today' order by update_time desc limit 1;")
        print('rs_api', rs_api)

        if len(rs_api) != 0 and rs_api[0][1] == 1: #已有记录，且最后一条记录的flag是1 。直接跳过不爬取。
            send_flag = False
        else:
            rs =  get_info_68(url,headers,seg_id,payload)
            assert rs["status"] == True
            bus_rs = []
            for item in rs["detail"]["zxStationRunDetailInfos"][:4]:
                if len(item["zxStationBusDetailInfos"]) != 0:
                    bus_rs.append(f'{item["stationName"]}\n{item["zxStationBusDetailInfos"][0]["arrivalTime"]}')

            print('bus_rs', bus_rs)

            if len(bus_rs) == 0:# 消息空忽略
                pass
            else:
                msg_str = "\n".join(bus_rs)
                if len(rs_api) == 0:  # 数据库还没记录
                    send_flag = True
                elif rs_api[0][0] == msg_str:  # 数据库已有至少一条记录，但消息和上次一样
                    send_flag = False
                else:
                    send_flag = True

                print('send_flag', send_flag)
                ### 最终判定
                if send_flag == True:
                    db.db_execute(
                    f"insert into t_bus_info (bus_date,segment_id,send_msg,update_time) values (timestamp 'today','{seg_id}','{msg_str}',now());",
                    'insert')
                    bus_rs.append('<a href="http://www.beyou.pub/api/bus_cancel/33463817">取消本次提醒</a>')
                    wechat.senddata("68路下行:火车站->南方泉\n\n" + "\n\n".join(bus_rs), ['eva'])


    except:
        wechat.senddata("获取信息失败，请联系管理员", ['henry', 'wangchao'])


nw = datetime.now()
if (nw.hour==17 and nw.minute >=56) or (nw.hour==18 and nw.minute<=20):
    bus_main_info_68()
else:
    print('not in plan time')

