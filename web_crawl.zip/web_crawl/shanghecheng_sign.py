import requests
from utils.logger import logger

def shc_sign():
	url = "https://m.shanghehui.com/api/v3/member/Big3a82Jb1W6RORO/signs"
	querystring = {"appKey":"498CZZDC","appUid":"Big3a82Jb1W6RORO","appVersion":"1.4.9","clientAppName":"memberClient","clientType":"liteApp","mallId":"1","model":"Other","osVersion":"mobile-1.4.9","rnd":"F21H1NJCK7ZHB1CNJTNLFVB1BNJRPU","sid":"Biv9ygzoDI61nr0G"}
	payload = "{\"mallId\":\"1\"}"
	headers = {
	'User-Agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36",
	'Content-Type': "application/json",
	'EncryptBody': "false",
	'CheckSession': "false",
	'CheckUserSession': "false",
	'SignCheck': "false",
	'cache-control': "no-cache"
	}
	response = requests.request("POST", url, data=payload, headers=headers, params=querystring)
	return response.text


try:
	shc_sign()
except Exception as e:
	logger.info(e)
