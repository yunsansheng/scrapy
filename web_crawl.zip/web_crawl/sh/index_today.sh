#!/bin/sh
python3 /apps/web_crawl/fund_alert.py
