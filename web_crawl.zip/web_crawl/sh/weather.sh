#!/bin/sh
python3 /apps/web_crawl/weather.py
