#!/bin/sh
python3 /apps/web_crawl/top10_fund.py
