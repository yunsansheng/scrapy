#!/bin/sh
python3 /apps/web_crawl/shanghecheng_sign.py
