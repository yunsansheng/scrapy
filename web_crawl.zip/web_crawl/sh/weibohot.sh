#!/bin/sh
python3 /apps/web_crawl/weibo_hot.py
