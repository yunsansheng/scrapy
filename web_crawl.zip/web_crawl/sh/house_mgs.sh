#!/bin/sh
python3 /apps/web_crawl/wx_house_msg.py
