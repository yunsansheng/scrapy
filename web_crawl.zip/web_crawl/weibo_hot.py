#coding:utf-8

import requests
from lxml import etree
from utils.dbclass  import Dbclass
from utils.wechat_msg import Wechat
import time
from utils.logger import logger

wechat=Wechat()


def weibohot():
	url = 'https://s.weibo.com/top/summary?cate=realtimehot'
	r = requests.get(url,headers= {"User-Agent":"Mozilla/5.0"})
	#print(r.text)
	selector=etree.HTML(r.text)
	data = selector.xpath('//div[@class="data"]/table/tbody/tr')

	now = time.strftime("%Y-%m-%d", time.localtime())

	rs = ['Weibo Hot:']
	for each in data[1:21]:
		seq = each.xpath('./td[@class="td-01 ranktop"]/text()')[0]
		keyword = each.xpath('./td[@class="td-02"]/a/text()')[0]
		hot = each.xpath('./td[@class="td-02"]/span/text()')[0]
		rs.append("{seq}. {keyword}".format(seq = seq,keyword=keyword,hot=hot))
		#itemurl = each.xpath('./td[@class="td-02"]/a/@href')[0]
		#keyword #hot
		#print(itemurl)

		# into database
		# sqleng.db_execute('''insert into t_weibohot (createdate,seq,keyword,hot) values('{now}'::date,{seq},'{keyword}',{hot});'''.format(now=now,
		# 	seq= seq,keyword= keyword,hot= hot),"weibo hot")

	# send message
	content = ('\n').join(rs)
	#print(content)
	wechat.senddata(content, ['henry', 'wangchao'])


try:
	weibohot()
except Exception as e:
	logger.info(e)


