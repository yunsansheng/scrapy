#coding:utf-8
import requests
import time
import json
from datetime import datetime
from datetime import timedelta
from utils.dbclass import Dbclass
from utils.logger import logger



db = Dbclass('ali_rmt')

gz = [
  "007202",
  "005918",
  "001549"
]






#http://www.thfund.com.cn/thfund/netvalue/008593






weekdict = {
    0:1,
    1:2,
    2:3,
    3:4,
    4:5,
    5:6,
    6:7
}

def fmt_time(t:int):
    org = str(t)[:10]
    int_org = int(org)
    timeArray = time.gmtime(int_org)
    year = timeArray.tm_year
    month = timeArray.tm_mon
    day = timeArray.tm_mday

    a = datetime(year, month, day)
    timestr = datetime.strftime(a, '%Y-%m-%d')
    timeweek = weekdict[a.weekday()]
    return timestr,timeweek,month


def to_db(data,fd_code):
    for i in range(len(data)-1):
        timestr,timeweek,mth = fmt_time(data[i][0])
        float = round((data[i+1][1]-data[i][1])/data[i][1],4)
        db.db_execute(f'''insert into t_fund (fund_code,p_date,week_num,month_num,jinzhi,float_num,p_stamp,update_time) 
            values('{fd_code}','{timestr}',{timeweek},{mth},{data[i][1]},{float},{data[i][0]},now())
            ON  CONFLICT ON CONSTRAINT t_fund_fund_code_p_stamp_key DO UPDATE SET update_time = now()''','insert')
        #print(f'''insert into t_fund (fund_code,p_date,week_num,month_num,jinzhi,float_num,p_stamp) values('{fd_code}','{timestr}',{timeweek},{mth},{data[i][1]},{float},{data[i][0]});''')


def get_data(fd_code):
    r = requests.get(f'http://www.thfund.com.cn/thfund/netvalue/{fd_code}')
    return r.json()[-10:]


## 存在则不用加



def main():
    for fd_code in gz:
        time.sleep(2)

        new_data = get_data(fd_code)
        to_db(new_data,fd_code)


main()


#
# with open('001458.json') as f:
#     data = json.load(f)
#     for i in range(len(data)-1):
#         timestr,timeweek,mth = fmt_time(data[i][0])
#         float = round((data[i+1][1]-data[i][1])/data[i][1],4)
#         print(f'''insert into t_fund (fund_code,p_date,week_num,month_num,jinzhi,float_num) values('001458','{timestr}',{timeweek},{mth},{data[i][1]},{float});''')
#         #print(timestr,timeweek,mth,data[i][1],float,sep='\t')


