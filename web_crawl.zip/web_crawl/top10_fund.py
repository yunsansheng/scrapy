#coding:utf-8
import requests
from lxml import etree
import re
import time
from utils.dbclass  import Dbclass
from utils.wechat_msg import Wechat
import json
from utils.logger import logger

db = Dbclass('ali_rmt')
wechat=Wechat()


# requests.adapters.DEFAULT_RETRIES = 5
# query = requests.session()
# query.keep_alive = False  # 关闭多余连接


'''
混合型五年 三年  二年 1年
http://fund.eastmoney.com/api/Dtshph.ashx?t=2&c=wndt&s=desc&issale=1&page=1&psize=100
http://fund.eastmoney.com/api/Dtshph.ashx?t=2&c=sndt&s=desc&issale=1&page=1&psize=100
http://fund.eastmoney.com/api/Dtshph.ashx?t=2&c=endt&s=desc&issale=1&page=1&psize=100
http://fund.eastmoney.com/api/Dtshph.ashx?t=2&c=yndt&s=desc&issale=1&page=1&psize=100
'''


def get_top_10(url,maxnum):
    headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close",
        "Content-Type": "text/html; charset=utf-8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Host": "fund.eastmoney.com",
        "Pragma": "no-cache",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36"
    }
    r = requests.get(url,headers = headers)
    page = r.text
    html = etree.HTML(page)
    top_10_nodes = html.xpath('//tbody/tr')[:maxnum]

    fund_codes_path = './td[3]/a/text()'



    top_10_rs = []
    for item in top_10_nodes:
        top_10_rs.append(item.xpath(fund_codes_path)[0])

    return top_10_rs


def format_msg(add_arr,del_arr,mapdata):
    msg = ['定投基金排行更新']

    if len(add_arr) !=0:
        add_msg = '新增基金\n'+ '\n'.join([i+'\t'+ mapdata.get(i,'none') for  i in add_arr])
        msg.append(add_msg)

    if len(del_arr) !=0:
        del_msg = '除名基金\n' + '\n'.join([i+'\t'+ mapdata.get(i,'none') for  i in del_arr])
        msg.append(del_msg)

    return '\n\n'.join(msg)


def main(fund_type,maxnum):
    r = requests.get("http://fund.eastmoney.com/api/Dtshph.ashx?t=2&c=wndt&s=desc&issale=1&page=1&psize=100")
    page = r.text
    html = etree.HTML(page)
    fund_dates = html.xpath('//tbody/tr/td[7]/text()')
    date_by = '|'.join(set(fund_dates))

    fund_codes = html.xpath('//tbody/tr/td[3]/a/text()')
    fund_titles = html.xpath('//tbody/tr/td[4]/a/text()')

    map_data = {x[0]:x[1] for x in zip(fund_codes,fund_titles)}
    #print(map_data)


    time.sleep(3)
    five_top_10 =  get_top_10(f'http://fund.eastmoney.com/api/Dtshph.ashx?t={fund_type}&c=wndt&s=desc&issale=1&page=1&psize=100',maxnum)
    time.sleep(3)
    three_top_10 = get_top_10(f'http://fund.eastmoney.com/api/Dtshph.ashx?t={fund_type}&c=sndt&s=desc&issale=1&page=1&psize=100',maxnum)
    time.sleep(3)
    two_top_10 = get_top_10(f'http://fund.eastmoney.com/api/Dtshph.ashx?t={fund_type}&c=endt&s=desc&issale=1&page=1&psize=100',maxnum)
    time.sleep(3)
    one_top_10 = get_top_10(f'http://fund.eastmoney.com/api/Dtshph.ashx?t={fund_type}&c=yndt&s=desc&issale=1&page=1&psize=100',maxnum)

    zh_top = set(five_top_10) & set(three_top_10) & set(two_top_10) & set(one_top_10)

    zh_rs = list(zh_top)
    zh_rs.sort(key=five_top_10.index)
    print(zh_rs)

    latest = db.db_query('select fund_comb from t_fund_top10 order by created_date desc limit 1;')[0][0]
    # print(type(latest))

    add_fund = set(zh_rs)- set(latest)
    del_fund = set(latest) - set(zh_rs)

    print(map_data)
    zx_fund = [ ' | '.join([x,map_data.get(x,'none')]) for x in zh_rs]
    zx_fund_str =  ' ++ '.join(zx_fund)

    print(zx_fund_str)

    if len(add_fund) >0 or len(del_fund) >0:
        db.db_execute(f'''insert into t_fund_top10(date_text,fund_comb,created_date) values ('{date_by}','{json.dumps(zh_rs)}',now())''', 'insert fund')
        # print('add',add_fund)
        # print('del',del_fund)
        send_msg = format_msg(add_fund,del_fund,map_data)
        print(send_msg+'\n'+zx_fund_str)
        wechat.senddata(send_msg, ['henry', 'wangchao'])
    else:
        wechat.senddata(f"今日基金定投排行无变化 {zx_fund_str}", ['henry', 'wangchao'])









#2 混合 ，4 指数
# main(4,30)
# main(2,15)

try:
    main(2, 15)
except Exception as e:
    logger.info(e)
    wechat.senddata('定投排行获取失败，请检查', ['henry', 'wangchao'])







# fund_scores = html.xpath('//tbody/tr/td[2]/text()')
# fund_codes = html.xpath('//tbody/tr/td[3]/a/text()')
# fund_urls = html.xpath('//tbody/tr/td[3]/a/@href')
# fund_title = html.xpath('//tbody/tr/td[4]/a/text()')
# fund_dates = html.xpath('//tbody/tr/td[7]/text()')
# fund_fst_years =html.xpath('//tbody/tr/td[8]/span/text()')
# fund_two_years =html.xpath('//tbody/tr/td[9]/span/text()')
# fund_three_years =html.xpath('//tbody/tr/td[10]/span/text()')
# fund_five_years =html.xpath('//tbody/tr/td[11]/span/text()')
#
#
# for row in zip(fund_scores,fund_codes,fund_urls,fund_title,fund_fst_years,fund_two_years,fund_three_years,fund_five_years):
#     print(row)
#

'''
04-17 top 10
{'519674', '213001', '000924', '161903'}


04-17 top 15
{'519674', '000924', '162703', '213001', '161903', '000727'}

混合定投top 10 变化提醒


指数定投top 10 变化提醒


'''