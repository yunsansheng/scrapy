#coding:utf-8
import requests
import re
import time
import json
from datetime import datetime
from datetime import timedelta
from utils.dbclass import Dbclass
from utils.logger import logger
from utils.wechat_msg import Wechat


wechat=Wechat()
db = Dbclass('ali_rmt')
MODE =0 # 1代表测试用，0代表线上环境，0的时候，只会发送当天的。

STAR_FUND_CODE = {
    "000727":"融通健康产业灵活",
    "162703":"广发小盘成长混合",
    "161903":"万家行业优选混合",
    "213001":"宝盈收益灵活配置",
    "003299":"嘉实物流产业股票",
    "001984":"上投摩根中国生物医药",
    "202003":"南方绩优成长混合A",
    "007202":"天弘优质成长企业"
}

'''
1. 已关注基金，近一周，一个月 三个月，半年的表现提醒
2. 已经关注基金 基金经理变动提醒。
3. 最近在持续上升的基金
'''


'''
A股今日表现
# 指数表现
http://www.csindex.com.cn/data/js/show_zsbx.js

今日涨几个，跌几个
TOP3  Last3


# 贡献指数
http://www.csindex.com.cn/data/js/show_gxzd.js

# 各板块信息
深市板块 http://www.csindex.com.cn/data/js/show_szbx.js
沪市板块 http://www.csindex.com.cn/data/js/show_shbx.js



'''
def if_none_then_kong(s):
    if s is None:
        return ''
    else:
        return s


def parse_data(s):
    try:
        m = re.match('.*\"(.*)\".*', s, flags=0)
        return m.group(1)
    except:
        return ''



def format_zsbx_msg(date,total,up_ct,down_ct,top5,down5):
    msg_lst = []

    msg_lst.append(f'今日指数表现({date})')
    msg_lst.append(f'总计：{total} \n多：{up_ct} 空：{down_ct}')
    if len(top5) >0:
        s1 = '\n'.join(['{name:<12}{sp:^8}{fd:>6}%'.format(name=item[0],sp=item[1],fd=item[2]) for item in top5])
        msg_lst.append('TOP5:\n' + s1)

    if len(down5) >0:
        s2 = '\n'.join(['{name:<12}{sp:^8}{fd:>6}%'.format(name=item[0],sp=item[1],fd=item[2]) for item in down5])
        msg_lst.append('Down5:\n' + s2)

    return '\n\n'.join(msg_lst)


def format_bkbx_msg(date,top5,down5):
    msg_lst = []

    msg_lst.append(f'今日板块表现({date})')
    if len(top5) >0:
        s1 = '\n'.join(['{name}\t{sp}\t{fd}'.format(name=item[0],sp=if_none_then_kong(item[1]),fd=if_none_then_kong(item[2])) for item in top5])
        msg_lst.append('TOP5:\n' + s1)

    if len(down5) >0:
        s2 = '\n'.join(['{name}\t{sp}\t{fd}'.format(name=item[0],sp=if_none_then_kong(item[1]),fd=if_none_then_kong(item[2])) for item in down5])
        msg_lst.append('Down5:\n' + s2)

    return '\n\n'.join(msg_lst)


def zsbx_main(mode):
    try:
        r = requests.get('http://www.csindex.com.cn/data/js/show_zsbx.js')
        data = r.content.decode('gbk').split('\r\n')
        #print(data)

        index_date = parse_data(data[0])
        print(index_date)

        index_name = [parse_data(i).strip() for i in data[1:-1]][::9]
        index_shoupan = [parse_data(i).strip() for i in data[1:-1]][1::9]
        index_percent = [parse_data(i).strip() for i in data[1:-1]][3::9]

        assert len(index_name) == len(index_shoupan) == len(index_percent)

        ## 入库

        for row in zip(index_name,index_shoupan,index_percent):
            db.db_execute(
                f'''insert into t_stock_zsbx (index_date,index_name,index_shoupan,index_percent,update_date)
                        values('{index_date}','{row[0]}',{row[1]},{row[2]},now())
                        ON  CONFLICT ON CONSTRAINT t_stock_zsbx_index_name_index_date_key DO UPDATE SET update_date = now();''',
                'insert')


        last_day,if_send_flag = db.db_query("select max(index_date),max(index_date)>(SELECT now()::timestamp + '-1 day') as yst from t_stock_zsbx;")[0]

        # 测试条件下或者，或者今天有推新

        if mode == 1 or if_send_flag ==True:
            total = db.db_query(f'''select count(*) from t_stock_zsbx  where index_date = '{last_day}';''')[0][0]
            up_ct = db.db_query(f'''select count(*) from t_stock_zsbx  where index_date = '{last_day}' and index_percent >=0;''')[0][0]
            down_ct = db.db_query(f'''select count(*) from t_stock_zsbx  where index_date = '{last_day}' and index_percent <0;''')[0][0]

            top5 = db.db_query(f'''select index_name,index_shoupan,index_percent from t_stock_zsbx  where 
                index_date = '{last_day}' and  index_percent >=0 order by index_percent desc limit 5;''')

            down5 = db.db_query(f'''select index_name,index_shoupan,index_percent from t_stock_zsbx  where 
                index_date = '{last_day}' and  index_percent <0 order by index_percent asc limit 5;''')

            send_msg = format_zsbx_msg(last_day,total,up_ct,down_ct,top5,down5)
            print(send_msg)
            wechat.senddata(send_msg, ['henry', 'wangchao'])

    except Exception as e:
        print(e)
        wechat.senddata('今日指数表现获取失败', ['henry', 'wangchao'])



def parse_bkdata(bkdata):
    lst1 = bkdata[1::2][::3]
    lst2 = bkdata[1::2][1::3]

    jg1 = bkdata[2::2][::3]
    jg2 = bkdata[2::2][1::3]

    rs = []
    for row in zip(lst1,jg1):
        rs.append((parse_data(row[0]),parse_data(row[1])))
    for row in zip(lst2,jg2):
        rs.append((parse_data(row[0]),parse_data(row[1])))

    return rs



def bankuai_bx_rk(url,bk_type):
    try:
        r = requests.get(url)
        dt = r.content.decode('gbk').split('\r\n')
        #print(dt)
        bk_date = parse_data(dt[0])
        data  = parse_bkdata(dt)
        print(data)




        for row in data:
            db.db_execute(
                f'''insert into t_stock_bkbx (bk_date,bk_name,bk_type,bk_percent,update_date)
                        values('{bk_date}','{row[0]}','{bk_type}',{row[1]},now())
                        ON  CONFLICT ON CONSTRAINT t_stock_bkbx_bk_name_bk_type_bk_date_key DO UPDATE SET update_date = now();''',
                'insert')


    except Exception as e:
        print(e)
        wechat.senddata(f'今日板块{bk_type}表现获取失败', ['henry', 'wangchao'])



def ifnone(s):
    if s is None:
        return 0
    else:
        return float(s)

def sort_func(elem):
    return ifnone(elem[1])+ifnone(elem[2])

def bankuai(mode):
    rs  = db.db_query('''
        select distinct(a.bk_name),b.bk_percent as sh_pc,c.bk_percent as sz_pc from t_stock_bkbx a 
    left join t_stock_bkbx b on a.bk_name = b.bk_name and b.bk_type = '沪市'
    left join t_stock_bkbx c on a.bk_name = c.bk_name and  c.bk_type = '深市'
    order by  sh_pc desc nulls last,sz_pc desc nulls last
''')
    #print(rs)
    # rs.sort(key=sort_func,reverse=True)
    # print(rs)

    top5 = sorted(rs, key=sort_func,reverse=True)[:5]
    down5 = sorted(rs, key=sort_func, reverse=False)[:5]
    print('top',top5)
    print('down',down5)



    try:
        last_day, if_send_flag = db.db_query("select max(bk_date),max(bk_date)>(SELECT now()::timestamp + '-1 day') as yst from t_stock_bkbx;")[0]
        if mode == 1 or if_send_flag == True:
            rs = db.db_query(f'''select distinct(a.bk_name),b.bk_percent as sh_pc,c.bk_percent as sz_pc from t_stock_bkbx a 
            left join t_stock_bkbx b on a.bk_name = b.bk_name and b.bk_type = '沪市' and b.bk_date = '{last_day}'
            left join t_stock_bkbx c on a.bk_name = c.bk_name and  c.bk_type = '深市' and c.bk_date= '{last_day}'
            where a.bk_date = '{last_day}'
            order by  sh_pc desc nulls last,sz_pc desc nulls last;
            ''')
            top5 = sorted(rs, key=sort_func, reverse=True)[:5]
            down5 = sorted(rs, key=sort_func, reverse=False)[:5]
            print('top', top5)
            print('down', down5)

            send_msg = format_bkbx_msg(last_day, top5, down5)
            print(send_msg)
            wechat.senddata(send_msg, ['henry', 'wangchao'])



    except Exception as e:
        print(e)
        wechat.senddata(f'今日板块表现获取失败', ['henry', 'wangchao'])



'''
https://danjuanapp.com/djapi/fund/manager/history?fd_code=000727


'''


def fnd_change(code):
    pass



def fnd_mange_change(codes):
    headers = {
        "Content-Type": "application/json, text/plain, */*",
        "User-Agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1"
    }
    changed_manager_lst = []

    for code in codes:
        time.sleep(3)
        r = requests.get(f'https://danjuanapp.com/djapi/fund/manager/history?fd_code={code}',headers=headers)
        print(r.text)
        try:
            rs = r.json()
            last  = rs["data"]["items"][0]["name"]
            ts = rs["data"]["items"][0]["post_date"]/1000
            timestr = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))
            #print(last,timestr)
            r_ct = db.db_execute(f'''insert into t_fund_manager(fund_code,manager_name,post_date) 
                                values('{code}','{last}','{timestr}') ON CONFLICT ON CONSTRAINT t_fund_manager_fund_code_manager_name_post_date_key DO nothing;''',
                                 'hs')
            # print(r_ct)
            if r_ct == 1:
                changed_manager_lst.append((code, last, timestr))



        except Exception as e:
            wechat.senddata(f'基金{code}经理信息获取失败', ['henry', 'wangchao'])

    if len(changed_manager_lst) !=0:
        send_msg_lst = ["关注基金经理变动提醒:\n"]
        for item in changed_manager_lst:
            send_msg_lst.append(f'''{item[0]} {STAR_FUND_CODE[item[0]]}\n{item[1]} {item[2]} ''')

        wechat.senddata('\n\n'.join(send_msg_lst), ['henry', 'wangchao'])




'''
表现稳定的基金（近1周，1月，3月，6月，1年TOP 50) 全部类型。
也是一样，做排行变化



'''




'''
发现趋势（涨）
近五日TOP10

股票型 https://danjuanapp.com/djapi/v3/filter/fund?type=1&order_by=1m&size=20&page=1
混合型 https://danjuanapp.com/djapi/v3/filter/fund?type=3&order_by=1m&size=20&page=1
QDII型 https://danjuanapp.com/djapi/v3/filter/fund?type=11&order_by=1m&size=20&page=1
指数(宽基) https://danjuanapp.com/djapi/v3/filter/fund?type=1002&order_by=1w&size=20&page=1
指数(行业）https://danjuanapp.com/djapi/v3/filter/fund?type=1004&order_by=1m&size=20&page=1
海外指数 https://danjuanapp.com/djapi/v3/filter/fund?type=1005&order_by=1m&size=20&page=1
海外股票 https://danjuanapp.com/djapi/v3/filter/fund?type=2003&order_by=1m&size=20&page=1

+ 总上榜天数
+ 近一周上榜天数
'''

# name_map = {
#     1:"股票型",
#     3:"混合型",
#     11:"QDII型",
#     1002:"指数(宽基)",
#     1004:"指数(行业",
#     1005:"海外指数",
#     2003:"海外股票"
# }

#
# # period 1w wm  ... 不过接口没有返回日期，需要自己自行判断
# def  fund_trend_alert(type,period):
#     headers = {
#         "Content-Type": "application/json, text/plain, */*",
#         "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1"
#     }
#     time.sleep(3)
#     try:
#         r = requests.get(f'https://danjuanapp.com/djapi/v3/filter/fund?type={type}&order_by={period}&size=20&page=1',
#                          headers=headers)
#         rs = r.text
#         print(rs)
#         # 入库
#         db.db_query('select ')
#
#     except:
#         wechat.senddata(f'趋势{name_map[type]}信息获取失败', ['henry', 'wangchao'])
#


## 存库


# fund_trend_alert(1,"1w")





'''
优矿
通联数据
天元数据

'''


###
#跌幅趋势
###




zsbx_main(MODE)

bankuai_bx_rk('http://www.csindex.com.cn/data/js/show_shbx.js','沪市')
bankuai_bx_rk('http://www.csindex.com.cn/data/js/show_szbx.js','深市')

bankuai(MODE)



fnd_mange_change(STAR_FUND_CODE.keys())


