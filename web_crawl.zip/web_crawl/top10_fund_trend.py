#coding:utf-8
import requests
from lxml import etree
import re
import time
from utils.dbclass  import Dbclass
from utils.wechat_msg import Wechat
import json
from utils.logger import logger

db = Dbclass('ali_rmt')
wechat=Wechat()


requests.adapters.DEFAULT_RETRIES = 5
s = requests.session()
s.keep_alive = False


'''
近一周涨幅TOP 10
desc asc
所有 fudtype:0
股票型 fundtype: 25  "FUNDTYPE":"001"
混合型 fundtype: 27 "FUNDTYPE":"002"
QDII  fundtype: 6   "FUNDTYPE":"007"
指数  fundtype: 26  "FUNDTYPE":"007"
ETF  fundtype: 3  "FUNDTYPE":"001"
ETF联接 fundtype: 33 "FUNDTYPE":"001"
债券 fundtype: 31 "FUNDTYPE":"003"
'''
fund_type_map = {
    "001":"股票型",
    "002":"混合型",
    "003":"债券型",
    "007":"QDII"
}

def get_last_week_top_trend(sort_type):
    url = f'http://fundmobapi.eastmoney.com/FundMNewApi/FundMNRankNewList?fundtype=0&SortColumn=SYL_Z&Sort={sort_type}&pageIndex=1&pagesize=30&deviceid=Wap&plat=Wap&product=EFund&version=2.0.0'
    headers = {
        "Accept":"*/*",
        "Accept-Encoding":"gzip, deflate, br",
        "Connection":"close",
        "Content-Type":"text/html; charset=utf-8",
        "Accept-Language":"zh-CN,zh;q=0.9",
        "Host":"fund.eastmoney.com",
        "Pragma":"no-cache",
        "Referer":"http://fund.eastmoney.com/data/fundranking.html",
        "User-Agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1"
    }

    r = s.get(url,headers=headers,verify=False)
    logger.info(r.text)
    return r.json()


def last_week_top_main(sort_type):
    assert  sort_type in ('asc','desc')
    QUERY_TABLE = ''
    if sort_type == 'asc':
        QUERY_TABLE = 't_fund_week_down'
    elif sort_type =='desc':
        QUERY_TABLE = 't_fund_week_top'

    rs = get_last_week_top_trend(sort_type)
    logger.info(rs)
    try:

        if int(rs["ErrorCode"]) ==0 and len(rs["Datas"]) != 0:
            # QDII是晚一天的
            fund_date = max([x["FSRQ"] for x in rs["Datas"]])
            ft_data = [(x["FSRQ"],x["FCODE"],x["SHORTNAME"],x["FUNDTYPE"],x["SYL_Z"]) for x in rs["Datas"] if x["FUNDTYPE"] not in ("003","008","007") and x["FSRQ"] ==fund_date]
            logger.info(ft_data)

            last_db_date = db.db_query(f"select distinct(fund_date) from {QUERY_TABLE}  where fund_date ='{fund_date}';")

            if len(last_db_date) ==0 and len(ft_data)!=0:

                for item in ft_data:
                    db.db_execute(
                        f'''insert into {QUERY_TABLE} (fund_date,fd_code,fd_name,fd_type,week_zd) values ('{item[0]}','{
                        item[1]}','{item[2]}','{item[3]}',{item[4]});''', 'insert row')

                query_rs = db.db_query(f'''select og.fd_name,og.fd_code,og.week_zd,tmp_ct.ct from {QUERY_TABLE} og
                 left join (select fd_code,count(fd_code) as ct from {QUERY_TABLE} where fund_date 
                    in (select distinct(fund_date) from {QUERY_TABLE} order by fund_date desc limit 7) group by fd_code ) as tmp_ct 
                    on tmp_ct.fd_code =og.fd_code
                    where og.fund_date = '{fund_date}';''')

                if len(query_rs)!=0:
                    msg_lst = [f"今日周趋势分析{fund_date} {sort_type}"]
                    for row in list(query_rs)[:10]:
                        msg_lst.append(f'''{row[0]}\n{row[1]} {row[2]} 7d: {row[3]}''')

                    msg_str = '\n\n'.join(msg_lst)
                    wechat.senddata(msg_str, ['henry', 'wangchao'])

            else:
                logger.info('今日数据已更新')
                print('今天数据已更新')

    except Exception as e:
        logger.info(e)
        wechat.senddata("今日基金周趋势获取失败", ['henry', 'wangchao'])





try:
    last_week_top_main('desc')
except Exception as e:
    logger.info(e)
    wechat.senddata('周趋势获取失败，请检查', ['henry', 'wangchao'])

time.sleep(10)

try:
    last_week_top_main('asc')
except Exception as e:
    logger.info(e)
    wechat.senddata('周趋势获取失败，请检查', ['henry', 'wangchao'])

