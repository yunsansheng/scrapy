#coding:utf-8
import re
import requests
import time
import json
from datetime import datetime
from datetime import timedelta
from utils.dbclass import Dbclass
from utils.logger import logger
from utils.wechat_msg import Wechat
from lxml import etree

wechat=Wechat()
db = Dbclass('ali_rmt')



'''
主体('//div[@class="list_right"]')
时间 :'//div[@class="list_right"]//div[@class="graylink"]/text()'
楼盘名称： //div[@class="list_right"]//tr[1]//span[@class="loupan_name"]/a/text()
链接'//div[@class="list_right"]//tr[1]//span[@class="loupan_name"]/a/@href'
消息 //div[@class="list_right"]//tr[2]/td/text()
'''

def rp_kong(s):
    try:
        return s.replace(' ','').replace('\r\n\t\t','')
    except:
        return ''



def house_one_msg():
    payload = 'proserh.status=&pager.currentPage=1'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36',
        'Content-Length': '35',
        'Cookie': '__jsluid_h=95b4fa6af032bcd8c1c3d69051e5834c; UM_distinctid=170e3ccc194d4-05fb49dc7e77f5-396d7407-13c680-170e3ccc198190; JSESSIONID=7C29A02397C0D9FC876119ED2D85B219; CNZZDATA1260707180=670418415-1584365600-null%7C1587626529',
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    try:

        url = 'http://www.wxhouse.com/listallinfo'
        r = requests.post(url, headers=headers, data = payload)
        #print(r.text)

        html = etree.HTML(r.text)
        all_nodes = html.xpath('//div[@class="list_right"]')
        send_msg = []

        try:
            for node in all_nodes:
                l_time = node.xpath('.//div[@class="graylink"]/text()')[0].replace('更新时间：', "")
                loupan = node.xpath('.//tr[1]//span[@class="loupan_name"]/a/text()')[0]
                l_url = 'http://www.wxhouse.com' + node.xpath('.//tr[1]//span[@class="loupan_name"]/a/@href')[0]
                l_msg = rp_kong(node.xpath('.//tr[2]/td/text()')[0])
                #print(l_time, loupan, l_url, l_msg)



                r_ct = db.db_execute(f'''insert into t_wxhouse_msg(msg_date,loupan,l_url,l_msg) 
                    values('{l_time}','{loupan}','{l_url}','{l_msg}') ON CONFLICT ON CONSTRAINT t_wxhouse_msg_msg_date_loupan_key DO nothing;''','hs')
                #print(r_ct)
                if r_ct ==1:
                    send_msg.append((l_time, loupan, l_url, l_msg))



        except:
            wechat.senddata("楼盘新消息获取失败code 1", ['henry', 'wangchao'])
        finally:
            if len(send_msg) !=0:
                print(send_msg)
                msg_lst = ["每日楼盘消息更新："]
                for i in send_msg:
                    msg_lst.append(f'''{i[0]}\n<a href='{i[2]}'>{i[1]}</a>\n{i[3]}''')

                wechat.senddata('\n\n'.join(msg_lst), ['henry', 'wangchao','sandy'])


    except:

        wechat.senddata("楼盘新消息获取失败code 2", ['henry', 'wangchao'])

house_one_msg()


# wechat.senddata("<a href='http://www.baidu.com'>这个是新闻</a>", ['henry', 'wangchao'])