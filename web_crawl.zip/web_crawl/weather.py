#coding:utf-8
import requests
from utils.logger import logger
from utils.wechat_msg import Wechat
from datetime import datetime
import time

'''
wuxi: http://www.nmc.cn/rest/weather?stationid=58354
changzhou: http://www.nmc.cn/rest/weather?stationid=58343

天气提醒: 无锡
2020-04-07：晴-晴  22-7 微风-微风

未来几天天气：
2020-04-08：晴-晴  22-7 微风-微风
2020-04-08：晴-晴  22-7 微风-微风
2020-04-08：晴-晴  22-7 微风-微风
2020-04-08：晴-晴  22-7 微风-微风
2020-04-08：晴-晴  22-7 微风-微风

'''


weekdict = {
    0:"周一",
    1:"周二",
    2:"周三",
    3:"周四",
    4:"周五",
    5:"周六",
    6:"周日"
}

## week 0-6
def week_fmt(week:int):
    if week ==0:
        return '周'
    elif  week ==1:
        return '周一'
    elif week ==2:
        return "周二"
    elif week ==3:
        return "周三"
    elif week ==4:
        return "周四"
    elif week ==5:
        return "周五"
    elif week ==6:
        return "周六"




def if_same_get_uq(a,b):
    if str(a)=='9999':
        return b
    elif str(b) == '9999':
        return a
    elif a == b:
        return a
    else:
        return "-".join([a,b])


def sigle_day(obj):
    date = obj["date"]
    weeknum = datetime.strptime(date, '%Y-%m-%d').weekday()
    weekstr = weekdict[weeknum]

    day_info = obj["day"]["weather"]["info"]
    day_tmp = obj["day"]["weather"]["temperature"]
    day_wind = obj["day"]["wind"]["power"]

    night_info = obj["night"]["weather"]["info"]
    night_tmp = obj["night"]["weather"]["temperature"]
    night_wind = obj["night"]["wind"]["power"]

    return f"{weekstr}: {if_same_get_uq(day_info,night_info)}\t{if_same_get_uq(day_tmp,night_tmp)}℃ {if_same_get_uq(day_wind,night_wind)}"



def msg_handler(rs):
    if rs["code"] == 0:
        station = rs["data"]["predict"]["station"]["city"]
        predict_detail = rs["data"]["predict"]["detail"]
        pb_time = rs["data"]["predict"]["detail"]

        today = datetime.now().weekday()

        header = f"天气: {station} 今天:{datetime.now().strftime('%Y-%m-%d')} {weekdict[today]}"
        today = f"{sigle_day(predict_detail[0])} \n"
        others = ('\n').join([sigle_day(x) for x in predict_detail[1:]])

        content = '\n'.join([header,today,others])
        print(content)

        return content


    else:
        pass





def get_weather(city_code):
    url = f'http://www.nmc.cn/rest/weather?stationid={city_code}'
    r = requests.get(url)
    logger.info('GET weather %s %s',url,repr(r.text))
    msg = msg_handler(r.json())
    wechat=Wechat()
    wechat.senddata(msg, ['henry', 'wangchao','sandy'])






## 先无锡，再常州，再拼接
def main():
    get_weather(58343) #cz
    time.sleep(2)
    get_weather(58354) #wx


main()
