#coding:utf-8
import requests
from lxml import etree
import json
import re
import time
from .tool.database import sqleng
from .tool.wechat_msg import Wechat
#from tool.database import sqleng
#from tool.wechat_msg import Wechat
from urllib.parse import urlparse
from urllib.parse import parse_qs


class WXhouse():
	def __init__(self):
		self.url = "http://www.wxhouse.com/listpros"
		self.payload = '''------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"proserh.disCode\"\r\n\r\nBH\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"proserh.disIcon\"\r\n\r\n8390f65010a6b06f5b7d3ada9243eb2c\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"pager.currentPage\"\r\n\r\n{page}\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"proserh.orderr\"\r\n\r\ncreatetime\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--'''
		self.headers = {
		    'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
		    'User-Agent': "Mozilla/5.0",
		    'cache-control': "no-cache"
		}
		#self.max_page= self.get_max_page()
		self.now  = time.strftime("%Y-%m-%d", time.localtime())

	def get_max_page(self):
		r = requests.post(self.url,headers = self.headers,data= self.payload.format(page=1))
		selector=etree.HTML(r.text)
		pat_str = selector.xpath('//div[@class="page"]/text()[2]')[0].strip()
		max_page = int(re.match('.*页/(\d+)页.*',pat_str).groups()[0])
		#print(max_page)
		return max_page

	def query_exist(self,name):
		rs = sqleng.db_query("select count(*) from t_wxhouse where name = '{name}';".format(name=name))
		#print(rs[0][0])
		if rs[0][0] == 0 :
			# this is new
			return True
		else:
			return False

	def query_news_exist(self,hid,datestring):
		rs = sqleng.db_query("select count(*) from t_wxhouse_news where houseid = '{hid}' and datestring='{datestring}';".format(hid=hid,
			datestring=datestring))
		#print(rs[0][0])
		if rs[0][0] == 0 :
			# this is new
			return True
		else:
			return False
	def first_or_null(self,lst):
		#print(lst)
		if bool(lst) == True:
			return lst[0]
		else:
			return False

	def query_trade_exist(self,tradeid):
		rs = sqleng.db_query("select count(*) from t_wxhouse_trades where tradeid = '{tradeid}';".format(tradeid=tradeid))

		#print(rs[0][0])
		if rs[0][0] == 0 :
			# this is new
			return True
		else:
			return False

	def get_id_by_par(self,parseurl,attr="pro.icon"):
		querys = urlparse(parseurl).query 
		dct = dict([(k,v[0]) for k,v in parse_qs(querys).items()])
		return dct[attr]


	def get_housename_by_id(self,houseid):
		rs = sqleng.db_query("select name from t_wxhouse where houseid = '{houseid}' limit 1;".format(houseid=houseid))[0][0]
		return rs


	def parse_data(self):
		newly = []
		maxpage = self.get_max_page()
		for pg in range(1,maxpage+1):
			time.sleep(2)
			r = requests.post(self.url,headers = self.headers,data= self.payload.format(page=pg))
			selector=etree.HTML(r.text)
			house = selector.xpath('//div[@class="fyarea"]')
			newly = []

			for each in house:
				name = each.xpath('.//span[@class="lptitle"]/text()')[0].strip()
				#status = 
				url = 'http://www.wxhouse.com/'+each.xpath('.//div[@class="fy_info fl"]//a/@href')[0]
				houseid = self.get_id_by_par(url)
				address = each.xpath('.//div[@class="biaoqian"]/text()')[0].strip()
				price = each.xpath('.//div[@class="fy_price fr"]/h1/text()')[0].strip()
				#sales = each.xpath('.//div[@class="fy_price fr"]/node()')[-2]
				if self.query_exist(name) == True:
					newly.append(name)
					sqleng.db_execute('''insert into t_wxhouse (houseid,name,address,url,price) values('{houseid}','{name}','{address}','{url}','{price}');'''.format(houseid = houseid,
						name=name,address = address,url=url,price= price),"wx house")

		return newly

	def get_ids(self):
		
		rs = sqleng.db_query("select houseid from t_wxhouse")
		ls = [x[0] for x in rs]
		print(ls)
		return ls

	def get_trade_urls(self):
		houseids = tuple(self.get_ids())
		rs = sqleng.db_query("select tradeurl from t_wxhouse_trades where houseid in {houseids}".format(houseids=houseids))
		return [x[0] for x in rs]

		#return ['/listsaleinfo?pro.icon=dc54ebec77ceae280e5e4a33bc7f1333&kstrr=f6e1c800a1617b63b42b0c14dc8648a9','/listsaleinfo?pro.icon=dc54ebec77ceae280e5e4a33bc7f1333&kstrr=a37fee7cd0111a1477c127581292cf18']

	def get_news(self):
		# only check newlyst
		# add table t_wxhouse_news
		# houseid(varchar),datestring(varchar),news(varchar) 

		newsls = []
		houseids = self.get_ids()
		for hid in houseids:
			time.sleep(3)
			newsurl = 'http://www.wxhouse.com/listproinfo?pro.icon={hid}'.format(hid=hid)
			r = requests.get(newsurl,headers = {'User-Agent':'Mozilla/5.0'})
			selector=etree.HTML(r.text)
			housename = selector.xpath('//span[@class="lptitle"]/text()')[0]
			datastring = time.strftime("%Y-%m-%d", time.localtime())
			#datestring = selector.xpath('//div[@class="news_row"][1]//p[@class="news_year"]/text()')[0]+'年'+selector.xpath('//div[@class="news_row"][1]//p[@class="news_md"]/text()')[0]
			datestring = self.now
			news = selector.xpath('//div[@class="news_row"][1]//div[@class="news_content fr border_radius"]/text()')[1].strip()
			#print(housename,datestring,news)

			if self.query_news_exist(hid,datestring) == True:
				sqleng.db_execute('''insert into t_wxhouse_news(houseid,datestring,news) 
					values('{hid}','{datestring}','{news}');'''.format(hid=hid,datestring=datestring,news=news),"add news")
				newsls.append('[{housename}] {datestring} : {news}'.format(housename=housename,
					datestring=datestring,news=news))
				
			

		return newsls


	def get_new_trade(self):
		# t_wxhouse_trades
		# tradeid(varchar),tradename(varchar),tradeurl(varchar),houseid(varchar)
		# 如果是新的，发送new
		print('start get new trade')

		newtrades = []
		houseids = self.get_ids()
		for hid in houseids:
			print(hid)
			time.sleep(3)
			tradeurl = 'http://www.wxhouse.com/listsaleinfo?pro.icon={hid}'.format(hid=hid)
			r = requests.get(tradeurl,headers = {'User-Agent':'Mozilla/5.0'})
			selector=etree.HTML(r.text)
			tradesel = selector.xpath('//div[@class="fl"]//a')
			housename = self.get_housename_by_id(hid)
			for each in tradesel:
				#print(tradesel)
				tradeid = self.first_or_null(each.xpath('.//li/@id'))
				tradeurl =self.first_or_null(each.xpath('./@href'))
				tradename = self.first_or_null(each.xpath('.//li/text()'))
				#print('LL',tradeid,tradeurl,tradename)
				if tradeid != False:
					if self.query_trade_exist(tradeid) == True:
						sqleng.db_execute('''insert into t_wxhouse_trades(tradeid,tradename,tradeurl,houseid) 
							values('{tradeid}','{tradename}','{tradeurl}','{hid}');'''.format(tradeid=tradeid,tradename=tradename,
								tradeurl= tradeurl,hid=hid),'add trade')
						newtrades.append('{housename} add {tradename}'.format(housename=housename,tradename=tradename))

		
		return newtrades


	def get_trade_by_day(self):
		print('start trade by day')
		# t_wxhouse_trade_days
		# date, trade id ,houseid,sale,sold,keepnum,holdnum
		tdurls = self.get_trade_urls()
		sqleng.db_execute("delete from t_wxhouse_trade_days where createdate = '{now}';".format(now=self.now),'del todays')
		for tdurl in tdurls:
			time.sleep(3)
			houseid = self.get_id_by_par(tdurl)
			tradeid = self.get_id_by_par(tdurl,attr="kstrr")
			r = requests.get('http://www.wxhouse.com'+tdurl,headers = {'User-Agent':'Mozilla/5.0'})
			selector=etree.HTML(r.text)
			sale = len(selector.xpath('//div[@id="tabtabm31"]//td[@class="bg_sale"]'))
			sold = len(selector.xpath('//div[@id="tabtabm31"]//td[@class="bg_sold"]'))
			hold = len(selector.xpath('//div[@id="tabtabm31"]//td[@style="background:#ccc"]'))
			#keep = 
			print(sale,sold,hold)

			# into database
			sqleng.db_execute('''insert into t_wxhouse_trade_days (createdate,tradeid,houseid,sale,sold,hold) 
				values('{now}','{tradeid}','{houseid}',{sale},{sold},{hold});'''.format(now=self.now,
					tradeid=tradeid,houseid= houseid,sale=sale,sold=sold,hold=hold),'add today trade')

	def cal_change(self):
		change_rs = sqleng.db_query('''
			select h.name,rs.c_sale,rs.c_sold from (select hs.houseid,newtmp.tradeid,c_sale,c_sold
from (select td.tradeid,COALESCE(td.sale,0)-COALESCE(yd.sale,0) as c_sale,
COALESCE(td.sold,0)-COALESCE(yd.sold,0) as c_sold from (select tradeid,sale,sold  from t_wxhouse_trade_days
where createdate in (select createdate from (select distinct(createdate) createdate from t_wxhouse_trade_days order by createdate desc limit 1) as tb2)) as td
left join 
(select tradeid,sale,sold  from t_wxhouse_trade_days
where createdate in (select createdate from (select distinct(createdate) createdate from t_wxhouse_trade_days order by createdate desc limit 2) as tba
EXCEPT
select createdate from (select distinct(createdate) createdate from t_wxhouse_trade_days order by createdate desc limit 1) as tb2
)) as yd
on td.tradeid = yd.tradeid) as newtmp
inner join t_wxhouse_trades as hs
on newtmp.tradeid = hs.tradeid
where c_sale<>0 or c_sold<>0) as rs
inner join t_wxhouse as h
on rs.houseid = h.houseid''')
		a=  ['{name}:库存增加或减少:{sales},卖出:{sold}'.format(name=x[0],sales= str(x[1]),sold = str(x[2])) for x in change_rs]
		print(a)
		return a












	def send_msg(self,newly,news,newtrades,change_rs):
		wechat=Wechat()
		if bool(newly) == True:
			wechat.senddata("太湖新城新增楼盘:\n"+'\n'.join(newly),'wangchao')
		if bool(news) == True:
			wechat.senddata("楼盘状态有更新:\n"+'\n'.join(news),'wangchao')
		if bool(newtrades) == True:
			wechat.senddata("新增可售房源:\n"+'\n'.join(newtrades),'wangchao')
		if bool(change_rs) == True:
			wechat.senddata("房源交易变化:\n"+'\n'.join(change_rs),'wangchao')





				

				#print(name)
				#print(url)
				#print(address)
				#print(price)

# 新增楼盘信息
# 每个原来的楼盘信息









if __name__ == "__main__":
    wxhouse = WXhouse()

    # # get new house 
    # newly = wxhouse.parse_data()
    # print(newly)
    

    # # get news of all house
    
    # news = wxhouse.get_news()
    # print(news)
    

    # # get new trade
    
    # newtrades = wxhouse.get_new_trade()
    # print(newtrades)
    

    # # get trade by day
    # wxhouse.get_trade_by_day()

    wxhouse.cal_change()









