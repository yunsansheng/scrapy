#coding:utf-8
import requests
from lxml import etree
import re
import time

'''
https://wx.5i5j.com/sold/348254/
https://wx.5i5j.com/sold/348254/n2/


https://wx.5i5j.com/sold/37576138.html


我爱我家 （26）
https://wx.5i5j.com/ershoufang/o8/_%E6%9C%97%E8%AF%97%E5%A4%AA%E6%B9%96%E7%BB%BF%E9%83%A1/



朗诗太湖（链家） 
https://wx.lianjia.com/chengjiao/c4120023222488907/


'''



def crawl_sold_wawj():
    urls = ['https://wx.5i5j.com/sold/348254','https://wx.5i5j.com/sold/348254/n2']

    for ul in urls:
        r = requests.get(ul)
        html = etree.HTML(r.text)
        print(r.text)
        page_urls = html.xpath('//ul[@class="pList zu"]/li/a/@href')
        print(page_urls)
        for p_url in page_urls:
            time.sleep(3)
            new_url = 'https://wx.5i5j.com'+p_url
            print(new_url)
            r2= requests.get(new_url)
            print(r2.text)

            html_p = etree.HTML(r2.text)
            title = html_p.xpath('//h1[@class="house-tit fl"]/text()')[0].strip()

            # cj_price = html_p.xpath('//div[@class="cjprice fl"]//p[@class="cjinfo"]/text()')[0].strip()
            # cj_dj = html_p.xpath('//div[@class="cjdj fl"]//p[@class="cjinfo"]/text()')[0].strip()
            # cj_date = html_p.xpath('//div[@class="cjdata fl"]//p[@class="cjinfo"]/text()')[0].strip()
            print(title)
            break



def crwal_page(url):
    time.sleep(2)
    r = requests.get(url)
    html_p = etree.HTML(r.text)
    title = html_p.xpath('//h1[@class="house-tit fl"]/text()')[0].strip()
    cj_price = html_p.xpath('//div[@class="cjprice fl"]//p[@class="cjinfo"]/text()')[0].strip()
    cj_dj = html_p.xpath('//div[@class="cjdj fl"]//p[@class="cjinfo"]/text()')[0].strip()
    cj_date = html_p.xpath('//div[@class="cjdata fl"]//p[@class="cjinfo"]/text()')[0].strip()
    print(title,cj_price,cj_dj,cj_date)




# crwal_page('https://wx.5i5j.com/sold/43212713.html')


def crawl_lianjia(url):
    time.sleep(3)
    r = requests.get(url)
    html_p = etree.HTML(r.text)
    for item in html_p.xpath('//ul[@class="listContent"]/li'):
        title = item.xpath('.//div[@class="title"]/a/text()')[0]
        houseInfo = item.xpath('.//div[@class="houseInfo"]/text()')[0]
        dealDate = item.xpath('.//div[@class="dealDate"]/text()')[0]
        positionInfo = item.xpath('.//div[@class="positionInfo"]/text()')[0]
        totalPrice = item.xpath('.//div[@class="totalPrice"]/span/text()')[0]
        unitPrice = item.xpath('.//div[@class="unitPrice"]/span/text()')[0]
        print(title,houseInfo,dealDate,positionInfo,totalPrice,unitPrice,sep='\t')



crawl_lianjia('https://wx.lianjia.com/chengjiao/c4120023222488907/')


# crawl_sold_wawj()
